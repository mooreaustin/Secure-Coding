// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>

// Create a custom exception
struct CustomException : public std::exception
{
    const char* what() const throw()
    {
        return "Austin's Custom Exception";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throw a standard exception
    throw std::exception();

    return true;
}

void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;

    try 
    {
        if(do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }

    // Catch the o_even_more_custom_application_logic exception
    catch (std::exception& e) 
    {
        std::cout << "An exception occured. " << e.what() << '\n';
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

    // Throw custom exception class
    throw (CustomException());
}

float divide(float num, float den)
{
  // Check for 0 in denominator and throw overflow error
  if (den == 0) 
  {
    throw std::overflow_error("Divide by zero exception.");
    return (num / den);
  }
}

void do_division() noexcept
{

  float numerator = 10.0f;
  float denominator = 0;

  // Try and catch the division function + display the .what() error
  try 
  { 
    auto result = divide(numerator, denominator); 
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (std::overflow_error& e) 
  {
    std::cout << e.what() << " -> ";
  }
  std::cout << numerator << " / " << denominator << std::endl;
}

int main()
{
    do_division();
    // tries and catches all thrown exceptions
    try {
        std::cout << "Exceptions Tests!" << std::endl;
        do_custom_application_logic();
    }
    catch (CustomException& e) {
        std::cout << "Error Code: " << e.what() << '\n';
    }
    //catches standard exception
    catch (std::exception e) {
        std::cout << "Error Code: " << e.what() << '\n';
    }
    // catches all other cases of exceptions
    catch (...)
    {
        std::cout << "Exception caught of undetermined type\n";
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu